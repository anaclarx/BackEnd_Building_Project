package com.emse.spring.faircop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaircopApplicationTests {

	@Test
	void contextLoads() {
	}

}
