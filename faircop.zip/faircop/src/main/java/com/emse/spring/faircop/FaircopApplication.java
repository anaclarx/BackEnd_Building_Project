package com.emse.spring.faircop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaircopApplication {

	public static void main(String[] args) {
		SpringApplication.run(FaircopApplication.class, args);
	}

}
